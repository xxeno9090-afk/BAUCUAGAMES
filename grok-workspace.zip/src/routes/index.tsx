import { createFileRoute } from "@tanstack/react-router";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return (
    <main className="shell">
      <p className="shell-fallback">Bau Cua Royale</p>
      <iframe
        className="shell-frame"
        src="/game/index.html"
        title="Bau Cua Royale"
      />
    </main>
  );
}
